function hisoblash() {
  const name = document.getElementById("name").value;
  const birthYear = parseInt(document.getElementById("birthYear").value);
  const birthMonth = parseInt(document.getElementById("birthMonth").value);
  const birthDay = parseInt(document.getElementById("birthDay").value);

  let countdownElement = document.getElementById("geriSayim");

  const updateCountdown = function () {
    let today = new Date();
    let currentYear = today.getFullYear();
    let currentMonth = today.getMonth() + 1;
    let currentDay = today.getDate();

    const nextBirthday = new Date(currentYear, birthMonth - 1, birthDay);
    if (nextBirthday < today) {
      nextBirthday.setFullYear(currentYear + 1);
    }

    let remainingTime = nextBirthday.getTime() - today.getTime();
    let secondsLeft = Math.floor(remainingTime / 1000);
    let minutesLeft = Math.floor(secondsLeft / 60);
    let hoursLeft = Math.floor(minutesLeft / 60);
    let daysLeft = Math.floor(hoursLeft / 24);

    secondsLeft %= 60;
    minutesLeft %= 60;
    hoursLeft %= 24;

    const countdown =
      daysLeft +
      " kun, " +
      hoursLeft +
      " soat, " +
      minutesLeft +
      " daqiqa, " +
      secondsLeft +
      " sekund";

    countdownElement.innerHTML =
      name + ", tug'ilgan kuniga " + countdown + " qoldi.";
  };

  // Intervallarni boshlang
  const countdownInterval = setInterval(updateCountdown, 1000);

  // Intervallarni to'xtatish uchun funksiya
  const stopCountdown = function () {
    clearInterval(countdownInterval);
  };

  // LocalStorage ga saqlash
  const userData = {
    name: name,
    birthYear: birthYear,
    birthMonth: birthMonth,
    birthDay: birthDay,
  };
  localStorage.setItem("userData", JSON.stringify(userData));

  // Sahifa yangilanishida intervallarni to'xtatish
  window.onbeforeunload = stopCountdown;
}

// Sahifa yuklanganda saqlangan ma'lumotlarni qaytarish
window.onload = function () {
  const savedData = localStorage.getItem("userData");
  if (savedData) {
    const userData = JSON.parse(savedData);
    document.getElementById("name").value = userData.name;
    document.getElementById("birthYear").value = userData.birthYear;
    document.getElementById("birthMonth").value = userData.birthMonth;
    document.getElementById("birthDay").value = userData.birthDay;
    hisoblash();
  }
};
